🏰 MAIN STREET ELECTRICAL PARADE (WDW 10K) - 3D TPU ARMOR PLATE
BAMBU LAB X1-CARBON / AMS MULTI-COLOR PRINTING GUIDE

PLATE VARIANT: FRONT (The Spinning Snail)
======================================================================
PHYSICAL SIZE: 214.37 mm W x 169.92 mm H (Target Width: 220.0 mm / ~8.7 in)
ACTIVE LEDS: 100 LEDs with 3x3mm open optical apertures

======================================================================
HOW TO IMPORT INTO BAMBU STUDIO / ORCASLICER:
======================================================================
METHOD 1: NATIVE .3MF PROJECT (RECOMMENDED)
1. Open Bambu Studio.
2. Drag and drop 'tpu_panel_front_multicolor.3mf' onto the build plate.
3. In the left panel (Process -> Objects), verify the parts are listed.
4. Assign your AMS filament slots (Slot 1 to 5) to the parts.

METHOD 2: SPLIT STLs (MULTI-PART MERGE)
1. In Bambu Studio, select your printer.
2. Select all STL files simultaneously:
   - tpu_panel_front_chassis_black.stl
   - tpu_panel_front_lid.stl
   - tpu_panel_front_color_red.stl
   - tpu_panel_front_color_gold.stl
   - tpu_panel_front_color_green.stl
   - tpu_panel_front_color_blue.stl
3. Drag all files together onto the build plate.
4. When prompted: "Load these files as a single object with multiple parts?"
   -> Click YES.
5. All parts will lock together in exact (0, 0, 0) 3D alignment.

======================================================================
FILAMENT / AMS SLOT MAPPING:
======================================================================
Slot 1 (Black 95A TPU):   Chassis Tray, 7mm Perimeter Rim, 16 Tabs, 100 Collars, Outlines
Rear Lid (TPU or PLA):    2.0mm Rear Cover Plate with Alignment Ridge & M2 Screw Holes
Slot 2 (Head, Neck & Foot):  Head, Neck & Foot
Slot 3 (Antennae, Spiral & Edge):  Antennae, Spiral & Edge
Slot 4 (Green Radial Stripes):  Green Radial Stripes
Slot 5 (Blue Radial Stripes):  Blue Radial Stripes

======================================================================
RECOMMENDED 95A TPU PRINT SETTINGS:
======================================================================
- Layer Height: 0.20mm Standard (0.16mm Optimal for fine face detail)
- Wall Loops: 3
- Infill: 100% Solid (flexible high-durability armor for race day)
- Nozzle Temp: 225°C - 235°C
- Bed Temp: 35°C (Textured PEI Plate - use glue stick if TPU sticks too firmly)
- Print Speed: 30 - 45 mm/s (TPU requires steady, unhurried flow)
- Wipe Tower: Enabled (Prime volume ~25-35 mm3)
======================================================================
