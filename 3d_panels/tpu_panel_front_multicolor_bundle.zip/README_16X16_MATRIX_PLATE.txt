🏰 MAIN STREET ELECTRICAL PARADE - 16x16 MATRIX HYBRID BACKLIGHT PLATE
VARIANT: FRONT (Pete's Dragon)
======================================================================
PLATE SIZE: 176.0 mm x 176.0 mm Square (Covers 160x160mm BTF 16x16 FPCB)
FACE THICKNESS: 0.60 mm (100% Full Z-Thickness Color Inlays, Top to Bottom)
BACKSIDE ALIGNMENT LIP: 2.0 mm (160.4 x 160.4 mm PCB Retaining Pocket)
TOTAL HEIGHT: 2.60 mm
WINDOWED LEDS: 50 Open Apertures (Ø 3.4mm Round Through-Holes)
BACKLIT LEDS: 12 Solid Diffused Glow Positions (Zero Holes)
SEWING HOLES: 4 Corner Sewing Holes (Ø 2.8mm at 4 Corners)
REMOVED FEATURES: No LED channels, no side walls, no screw holes, no eyelets, no zip-tie tunnels.
