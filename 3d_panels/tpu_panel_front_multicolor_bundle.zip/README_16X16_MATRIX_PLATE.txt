🏰 MAIN STREET ELECTRICAL PARADE - 16x16 MATRIX HYBRID BACKLIGHT PLATE
VARIANT: FRONT (Pete's Dragon)
======================================================================
PLATE SIZE: 176.0 mm x 176.0 mm Square (Covers 160x160mm BTF 16x16 FPCB)
FACE THICKNESS: 1.00 mm (100% Full Z-Thickness Color Inlays, Top to Bottom)
LED STANDOFF GAP: 3.0 mm
FRAME HEIGHT: 5.4 mm (2.0mm Pocket + 1.0mm Ledge + 2.4mm Gap)
TOTAL HEIGHT: 6.40 mm
WINDOWED LEDS: 50 Open Apertures (Ø 3.4mm Round Through-Holes)
BACKLIT LEDS: 27 Solid Diffused Glow Positions (Zero Holes)
SEWING HOLES: 4 Corner Sewing Holes (Ø 2.8mm at 4 Corners)
REMOVED FEATURES: No LED channels, no side walls, no screw holes, no eyelets, no zip-tie tunnels.
