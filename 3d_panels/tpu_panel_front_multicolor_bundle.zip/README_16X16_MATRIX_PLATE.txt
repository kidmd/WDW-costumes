🏰 MAIN STREET ELECTRICAL PARADE - 16x16 MATRIX HYBRID BACKLIGHT PLATE
VARIANT: FRONT (The Turtle)
======================================================================
PLATE SIZE: 176.0 mm x 176.0 mm Square (Covers 160x160mm BTF 16x16 FPCB)
THICKNESS: 0.60 mm (100% Full Z-Thickness Color Inlays)
WINDOWED LEDS: 50 Open Apertures (round_34)
BACKLIT LEDS: 25 Solid Diffused Glow Positions (Zero Holes)
SHIRT HOLES: 16 Perimeter Stitching Holes (Ø 2.8mm along 8mm margin)
