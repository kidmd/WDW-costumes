========================================================================
DOPEY PHOTOGRAPHER - runDisney 2026 FINISHER MEDAL (3D PRINT BUNDLE)
========================================================================

DIMENSIONS:
- Medal Diameter (Width) : 90.0 mm (3.54 inches)
- Total Height with Loop : 105.0 mm (4.13 inches)
- Total Thickness        : 6.0 mm (3.4mm solid base + 2.6mm sculpted 3D bas-relief)
- Top Ribbon Slot        : 38.6 mm x 4.2 mm (fits standard 1.5" / 38mm runDisney neck ribbons)

INCLUDED FILES:
1. dopey_photographer_medal_relief.stl
   - Single-piece monolithic 3D bas-relief medal.
   - Ideal for printing in Antique Gold / Bronze Silk PLA or Resin.

2. dopey_photographer_medal_multicolor.3mf
   - Pre-assembled 4-toolhead project file for Snapmaker U1 / OrcaSlicer / Bambu Studio.
   - Extruder 1 (T0): Antique Gold / Bronze Silk PLA (Main Medal & Sculpted Relief)
   - Extruder 2 (T1): Green PLA (Dopey's Hat)
   - Extruder 3 (T2): Purple / Lilac PLA (Dopey's Robe)
   - Extruder 4 (T3): Black / Dark Bronze PLA (Recessed Outlines & Lettering Shadows)
   - NOTE: Layers from Z = 0.00mm to 3.20mm print 100% in Extruder 1 (Bronze) with zero tool swaps!

3. Individual Multi-Color STLs (if importing manually as a multi-part object):
   - dopey_medal_1_bronze_body.stl
   - dopey_medal_2_green_hat.stl
   - dopey_medal_3_purple_robe.stl
   - dopey_medal_4_dark_outlines.stl

RECOMMENDED SLICER SETTINGS:
- Layer Height : 0.12 mm or 0.16 mm (for ultra-smooth relief gradation)
- Nozzle       : 0.4 mm (enable Arachne perimeter generator for crisp lettering)
- Infill       : 20% - 25% Gyroid (add extra perimeters/infill if you want hefty metal-like weight!)
- Supports     : NONE REQUIRED (100% flat back at Z = 0.00 mm)
