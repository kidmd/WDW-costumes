🏰 MAIN STREET ELECTRICAL PARADE (WDW 10K) - 3D TPU ARMOR PLATE
BAMBU LAB X1-CARBON / AMS MULTI-COLOR PRINTING GUIDE

PLATE VARIANT: BACK (The Turtle)
======================================================================
PHYSICAL SIZE: 203.16 mm W x 175.26 mm H (Target Width: 253.76 mm / ~10.0 in)
ACTIVE LEDS: 100 LEDs with 3x3mm open optical apertures

======================================================================
HOW TO IMPORT INTO BAMBU STUDIO / ORCASLICER:
======================================================================
METHOD 1: NATIVE .3MF PROJECT (RECOMMENDED)
1. Open Bambu Studio.
2. Drag and drop 'tpu_panel_back_multicolor.3mf' onto the build plate.
3. In the left panel (Process -> Objects), verify the parts are listed.
4. Assign your AMS filament slots (Slot 1 to 5) to the parts.

METHOD 2: SPLIT STLs (MULTI-PART MERGE)
1. In Bambu Studio, select your printer.
2. Select all STL files simultaneously:
   - tpu_panel_back_chassis_black.stl
   - tpu_panel_back_color_green.stl
   - tpu_panel_back_color_blue.stl
   - tpu_panel_back_color_yellow.stl
   - tpu_panel_back_color_red.stl
3. Drag all files together onto the build plate.
4. When prompted: "Load these files as a single object with multiple parts?"
   -> Click YES.
5. All parts will lock together in exact (0, 0, 0) 3D alignment.

======================================================================
FILAMENT / AMS SLOT MAPPING:
======================================================================
Slot 1 (Black 95A TPU):   Chassis Tray, 4mm Perimeter Rim, 16 Tabs, 100 Collars, Outlines
Slot 2 (Shell Plates & Glasses):  Shell Plates & Glasses
Slot 3 (Shell & Eyes):  Shell & Eyes
Slot 4 (Body & Head):  Body & Head
Slot 5 (Tie & Lips):  Tie & Lips

======================================================================
RECOMMENDED 95A TPU PRINT SETTINGS:
======================================================================
- Layer Height: 0.20mm Standard (0.16mm Optimal for fine face detail)
- Wall Loops: 3
- Infill: 100% Solid (flexible high-durability armor for race day)
- Nozzle Temp: 225°C - 235°C
- Bed Temp: 35°C (Textured PEI Plate - use glue stick if TPU sticks too firmly)
- Print Speed: 30 - 45 mm/s (TPU requires steady, unhurried flow)
- Wipe Tower: Enabled (Prime volume ~25-35 mm3)
======================================================================
