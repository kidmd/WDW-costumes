🏰 MAIN STREET ELECTRICAL PARADE - 16x16 MATRIX HYBRID BACKLIGHT PLATE
VARIANT: BACK (Flag & Eagle)
======================================================================
PLATE SIZE: 176.0 mm x 176.0 mm Square (Covers 160x160mm BTF 16x16 FPCB)
FACE THICKNESS: 0.60 mm (100% Full Z-Thickness Color Inlays, Top to Bottom)
LED STANDOFF GAP: 0.0 mm
FRAME HEIGHT: 2.0 mm (2.0mm Pocket + 1.0mm Ledge + 0.0mm Gap)
TOTAL HEIGHT: 3.00 mm
WINDOWED LEDS: 48 Open Apertures (Ø 3.4mm Round Through-Holes)
BACKLIT LEDS: 38 Solid Diffused Glow Positions (Zero Holes)
SEWING HOLES: 4 Corner Sewing Holes (Ø 2.8mm at 4 Corners)
REMOVED FEATURES: No LED channels, no side walls, no screw holes, no eyelets, no zip-tie tunnels.
